"""Property tests package."""
